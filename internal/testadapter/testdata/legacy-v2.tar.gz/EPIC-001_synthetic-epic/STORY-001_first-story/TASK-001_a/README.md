# Synthetic A — text preservation

## Description
First line.
Second line.

## Scope
Synthetic scope

## Acceptance Criteria
Preserve text and ordered checklist.
